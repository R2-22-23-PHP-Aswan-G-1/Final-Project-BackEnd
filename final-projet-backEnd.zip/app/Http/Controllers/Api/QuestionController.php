<?php

namespace App\Http\Controllers\api;
use App\Models\Question;
use App\Http\Requests\StoreQuestionRequest;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Route;

class QuestionController extends Controller
{
    public function index(){
        $question = Question::all();
        return $question ;
    }

    public function store(Request $request){
        $question = $request->all();
        $body = $question['body'];
        $user_id = $question['user_id'];
        Question::create([
            'body'=>$body,
            'user_id'=>$user_id,
        ]);
        return "done";
    }

    public function update(Request $request , $question){
        $questionup=Question::findOrFail($question);
        $question = $request->all();
        $body = $question['body'];
        $user_id = $question['user_id'];
        $questionup->update([
            
            'body'=>$body, 
        ]);
       return $this->index();
    }

    public function destroy($Id){
        
        Question::find($Id)->delete();
        return $this->index();
    }


}

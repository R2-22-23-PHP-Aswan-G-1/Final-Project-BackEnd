run this seeders respectively :

1 - php artisan db:seed --class = RoleSeeder
2 - php artisan db:seed --class = UserSeeder
4 - php artisan db:seed --class = InstructorSeeder
5 - php artisan db:seed --class = TrackSeeder


